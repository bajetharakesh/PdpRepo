package test.Framework;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Report {
	private  ExtentTest logger;
	private  String dayStamp;
	WebDriver driver;

	public Report(WebDriver wDriver){
	this.driver = wDriver;
	}

    public ExtentReports initiateExtentReport(String reportPath, String configPath) {
		dayStamp = new SimpleDateFormat("yyyy_MM_dd_kk_mm_ss").format(new Date());
        ExtentReports extent = new ExtentReports(System.getProperty("user.dir") + reportPath, false);
        extent.loadConfig(new File(System.getProperty("user.dir") + configPath));
        return extent;
    }
    public void terminateExtentReport(ExtentReports extent) {
        extent.flush();
        extent.close();
    }
    public void setLogger(ExtentTest logg) {
        logger = logg;
    }
    public void endTestCase(String result) {
        if (result.equalsIgnoreCase("pass")) {
            log("pass", "The Test Case is successfully passed");
        } else if (result.equalsIgnoreCase("fail")) {
            log("fail", "The Test Case is failed");
        }
    }

    public void log(String status, String msg) {
        if (status.equalsIgnoreCase("pass")) {
            logger.log(LogStatus.PASS, msg);
        } else if (status.equalsIgnoreCase("fail")) {
            logger.log(LogStatus.FAIL, msg);
			captureScreenShot();
        }
    }

    public void logTitle(String title) {
        logger.log(LogStatus.INFO, "HTML", title);
    }

	public void captureScreenShot() {
		//TODO: get current step name to image and take full page screenshot
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File source = ts.getScreenshotAs(OutputType.FILE);
			String timeStamp = new SimpleDateFormat("yyyy_MM_dd_kk_mm_ss").format(new Date());
			String desc = System.getProperty("user.dir") + "//test-output//Screenshot//" + dayStamp + "//" + timeStamp + ".jpg";
			File deFile = new File(desc);
			FileUtils.copyFile(source, deFile);
			System.out.println("Screenshot taken");
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
		}
	}

}
