package test.Framework;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;

public class WebDriverHelp {
    private WebDriver driver;
    private WebDriverWait wait;
    private ReadProperties prop;
    private Report rep;

    private void LaunchDriver() {
        try {
            WebDriverManager.chromedriver().version("81.0.4044.138").setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("start-maximized");
            options.addArguments("enable-automation");
            options.addArguments("--no-sandbox");
            options.addArguments("--disable-infobars");
            options.addArguments("--disable-browser-side-navigation");
            //URL url =  new URL("http://localhost:4444/wd/hub");
            //driver = new RemoteWebDriver(url,options);
            driver = new ChromeDriver(options);
            wait = new WebDriverWait(driver, 15);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public WebDriver getWebDriver() {
        //TODO: use enum to optimize code
        if (driver == null) {
            LaunchDriver();
            rep = new Report(driver);
        }
        return driver;
    }


    public void setProperties(ReadProperties properties) {
        prop = properties;
    }

    public void launchUrl(String url) {
        try {
            System.out.println("launch url");
            driver.get(url);
            rep.log("pass", url + " is successfully launched");

        } catch (Exception e) {
            e.printStackTrace();
            rep.log("fail", e.getMessage());
        }
    }

    public void click(String element) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(prop.getLocator(element))));
            driver.findElement(By.xpath(prop.getLocator(element))).click();
            //log("pass", "Clicked");


        } catch (Exception e) {
            e.printStackTrace();
            rep.log("fail", e.getMessage().substring(0, 121));
        }
    }

    public WebElement getEachElement(String element, int i) {
        //TODO: implement other methods of finding element
        try {
            wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(prop.getLocator(element))));
            //log("pass", "Found Element");
            return driver.findElements(By.xpath(prop.getLocator(element))).get(i);

        } catch (Exception e) {
            e.printStackTrace();
            rep.log("fail", e.getMessage().substring(0, 121));
        }
        return null;
    }

    public void click(WebElement webElement) {
        try {
            wait.until(ExpectedConditions.visibilityOf(webElement));
            webElement.click();
            rep.log("pass", "Clicked");

        } catch (Exception e) {
            e.printStackTrace();
            rep.log("fail", e.getMessage());
        }
    }

    public void enterValue(String element, String value) {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(element)));
            driver.findElement(By.xpath(element)).sendKeys(value);
            rep.log("pass", value + " is successfully entered");

        } catch (Exception e) {
            e.printStackTrace();
            rep.log("fail", e.getMessage());
        }
    }

    public void checkPageLoad() {
        try {
            String pageLoadStatus = null;
            JavascriptExecutor js;
            do {
                js = (JavascriptExecutor) driver;
                pageLoadStatus = (String) js.executeScript("return document.readyState");
            } while (!pageLoadStatus.equals("complete"));
            if (pageLoadStatus.equals("complete")) {
                //log("pass","Page loaded successfully");
            } else {
                rep.log("fail", "Issue in page loading" + driver.getCurrentUrl());
            }
        } catch (Exception e) {
            e.printStackTrace();
            rep.log("fail", e.getMessage());
        }
    }

    private int getTabsCount() {
        return driver.getWindowHandles().size();
    }

    private void OpenInNewTab(WebElement locator) {
        String LinkOpeninNewTab = Keys.chord(Keys.CONTROL, Keys.RETURN);
        locator.sendKeys(LinkOpeninNewTab);
        switchToTab(getTabsCount() - 1);
        checkPageLoad();
    }

    private boolean switchToTab(int iWindow) {
        boolean bFlag = false;
        int wait_timer = 3;

        while (wait_timer > 0 && !bFlag) {
            ArrayList<String> allTabs = new ArrayList(driver.getWindowHandles());
            if (allTabs.size() > iWindow) {
                driver.switchTo().window(allTabs.get(iWindow));
                bFlag = true;
                if (bFlag == true) {
                    break;
                    //	log("pass","tab switched successfully");
                }
            } else {
                try {
                    //TODO: Optimize this wait here
                    wait(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                --wait_timer;
                System.out.println("Window not Found:" + iWindow);
            }
        }

        return bFlag;
    }

    public void closeTab() {
        try {
            ArrayList<String> allTabs = new ArrayList(driver.getWindowHandles());
            int iWindow = allTabs.size() - 1;
            if (allTabs.size() > iWindow) {
                driver.switchTo().window(allTabs.get(iWindow)).close();
                switchToTab(getTabsCount() - 1);
            } else {
                System.out.println("Window not Found:" + iWindow);
            }
        } catch (Exception e) {
            e.printStackTrace();
            rep.log("fail", e.getMessage());
        }
    }

    public List<WebElement> FindList(String locator) {
        List<WebElement> elementList = null;
        elementList = driver.findElements(By.xpath(locator));
        return elementList;
    }

    public void ScrollTillElement(List<WebElement> element, int flavor) {
        //WebElement element = driver.findElement(By.xpath(locator));
//        ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();", element);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element.get(flavor));

        // Actions actions = new Actions(driver);
        //actions.moveToElement(element);
        //actions.perform();
    }

//TODO implement interface
// implement multithreading for parallel execution of different applications




}
