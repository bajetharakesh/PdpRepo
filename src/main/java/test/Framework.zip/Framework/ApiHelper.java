package test.Framework;

//public class ApiHelper {
//
//    private int getResponseCode(String url) {
//        int responseCode = 0;
//        try {
//            URL obj = null;
//            obj = new URL(url);
//            HttpURLConnection con = null;
//            con = (HttpURLConnection) obj.openConnection();
//            con.setRequestMethod("GET");
//            //con.setRequestProperty("User-Agent", USER_AGENT);
//            responseCode = con.getResponseCode();
//            System.out.println("GET Response Code :: " + responseCode + " Image URL " + url);
//            con.disconnect();
//        } catch (Exception e) {
//            e.printStackTrace();
//            log("fail", e.getMessage());
//        }
//        return responseCode;
//    }
//
//
//}
