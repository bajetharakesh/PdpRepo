package test.Framework;

public class ValidationPDP {

    private void checkBrokenImage(String locator) {
        try {
            int responseCode = getResponseCode(locator);
            if (responseCode / 400 != 1) {
                log("pass", "image is displayed as expected");
            } else {
                String url = driver.getCurrentUrl();
                log("fail", "image is broken or not present page URL is " + url);
            }
        } catch (Exception e) {
            e.printStackTrace();
            log("fail", e.getMessage());
        }
    }

    private void checkPreviewURL() {
        try {
            checkPageLoad();
            if (driver.getCurrentUrl().contains("preview")) {
                log("fail", "redirected to preview url");
            } else {
                //log("pass", "redirected to prod url only");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log("fail", e.getMessage());
        }
    }

    public void verifySizesForEachFlavorGrp2(int k) {
        String sizeValue = "";
        try {
            click("sizesDropdown");
            sizeValue = getEachElement("sizesAvailable", k).getAttribute("innerText");
            getEachElement("sizesAvailable", k).click();
            checkPageLoad();
            //checkBrokenImage(driver.findElement(By.xpath(prop.getLocator("ImagePDP"))).getAttribute("src"));
            try {
                checkBrokenImage(driver.findElement(By.xpath(prop.getLocator("ImagePDP"))).getAttribute("src"));
            } catch (Exception e) {
                String url = driver.getCurrentUrl();
                log("fail", "Image is not displayed for " + sizeValue + " URL is " + url);
                captureScreenShot();
            }
            checkPreviewURL();
            log("pass", "Verified Sizes, Images, Preview URL for Size " + sizeValue);
        } catch (Exception e) {
            e.printStackTrace();
            log("fail", e.getMessage());
        }
    }

    public void verifySizesForEachFlavor(int k, String sizeName) {
        String sizeValue = "";
        try {
            driver.navigate().refresh();
            checkPageLoad();
            click("sizesDropdown");
            //sizeValue = getEachElement("sizesAvailable", k).getAttribute("innerText");
            //getEachElement("sizesAvailable", k).click();
            //driver.findElement(By.xpath(prop.getLocator("sizesAvailable") + "[contains(.,'" + sizeName + "')]")).click();
            if (sizeName.contains("PACK")) {
                sizeName = sizeName.replace("ACK", "ack");
                sizeName = sizeName.replace("FL OZ", "fl oz");
            } else if (sizeName.contains("FL OZ")) {
                sizeName = sizeName.replace("FL OZ", "fl oz");
            } else if (sizeName.contains("bottle")) {
                sizeName = sizeName.replace("bottle", "Bottle");
            }
            driver.findElement(By.xpath("//ul/li[contains(.,'" + sizeName + "')]")).click();
            checkPageLoad();
            try {
                checkBrokenImage(driver.findElement(By.xpath(prop.getLocator("ImagePDP"))).getAttribute("src"));
            } catch (Exception e) {
                String url = driver.getCurrentUrl();
                log("fail", "Image is not displayed for " + sizeName + " URL is " + url);
                captureScreenShot();
            }
            checkPreviewURL();
            log("pass", "Verified Sizes, Images, Preview URL for Size " + sizeName);
        } catch (Exception e) {
            e.printStackTrace();
            log("fail", e.getMessage());
        }
    }

    public List<WebElement> verifyFlavorForEachProductCategoryGrp2(int flavor, String flavorName) {
        List<WebElement> sizesForEachFlavor = null;
        String LatestFlavorName = "";
        try {
            click("flavorsDropdown");
            flavorName = getEachElement("flavorsAvailable", flavor).getAttribute("innerText");
            //ScrollTillElement(driver.findElements(By.xpath(prop.getLocator("flavorsAvailable"))), flavor);
            //((JavascriptExecutor)driver).executeScript("window.scrollBy(200,300");
            getEachElement("flavorsAvailable", flavor).click();
            checkPageLoad();
            //checkBrokenImage(driver.findElement(By.xpath(prop.getLocator("ImagePDP"))).getAttribute("src"));
            try {
                checkBrokenImage(driver.findElement(By.xpath(prop.getLocator("ImagePDP"))).getAttribute("src"));
            } catch (Exception e) {
                String url = driver.getCurrentUrl();
                log("fail", "Image is not displayed for " + flavorName + " URL is " + url);
                captureScreenShot();
            }
            checkPreviewURL();
            sizesForEachFlavor = driver.findElements(By.xpath(prop.getLocator("sizesAvailable")));
            log("pass", "Verified Sizes, Images, Preview URL for Flavor " + flavorName);
        } catch (Exception e) {
            e.printStackTrace();
            String[] urlArray1 = driver.getCurrentUrl().split("/");
            LatestFlavorName = urlArray1[urlArray1.length - 1];
            log("fail", "Issue in the above PDP Page while changing " + LatestFlavorName + " flavor to next flavor values inside it are getting changed");
        }
        return sizesForEachFlavor;
    }

    public LinkedHashMap<Integer, String> verifyFlavorForEachProductCategory(int flavor, String flavorName, String FlavorName) {
        List<WebElement> sizesForEachFlavor = null;
        LinkedHashMap<Integer, String> sizesForEachFlavor2 = new LinkedHashMap<Integer, String>();
        sizesForEachFlavor2.clear();
        String LatestFlavorName = "";
        try {
            click("flavorsDropdown");
            //flavorName = getEachElement("flavorsAvailable", flavor).getAttribute("innerText");
            //ScrollTillElement(driver.findElements(By.xpath(prop.getLocator("flavorsAvailable"))), flavor);
            //((JavascriptExecutor)driver).executeScript("window.scrollBy(200,300");

            //getEachElement("flavorsAvailable", flavor).click();
            driver.findElement(By.xpath(prop.getLocator("flavorsAvailable") + "//*[contains(.,'" + FlavorName + "')]")).click();
            checkPageLoad();
            driver.navigate().refresh();
            checkPageLoad();
            try {
                checkBrokenImage(driver.findElement(By.xpath(prop.getLocator("ImagePDP"))).getAttribute("src"));
            } catch (Exception e) {
                String url = driver.getCurrentUrl();
                log("fail", "Image is not displayed for " + FlavorName + " URL is " + url);
                captureScreenShot();
            }
            checkPreviewURL();
            click("sizesDropdown");
            sizesForEachFlavor = driver.findElements(By.xpath(prop.getLocator("sizesAvailable")));
            for (int l = 0; l < sizesForEachFlavor.size(); l++) {
                String DropsizeName = "";
                DropsizeName = sizesForEachFlavor.get(l).getAttribute("innerText").trim();
                sizesForEachFlavor2.put(l, DropsizeName);
            }
            click("sizesDropdown");
            log("pass", "Verified Sizes, Images, Preview URL for Flavor " + FlavorName);
        } catch (Exception e) {
            e.printStackTrace();
            String[] urlArray1 = driver.getCurrentUrl().split("/");
            LatestFlavorName = urlArray1[urlArray1.length - 1];
            log("fail", "Issue in the above PDP Page while changing " + LatestFlavorName + " flavor to next flavor values inside it are getting changed");
        }
        return sizesForEachFlavor2;
    }

    public List<WebElement> verifyFlavorForEachProductCategoryPeacetea(int flavor, String flavorName) {
        List<WebElement> sizesForEachFlavor = null;
        //LinkedHashMap<Integer, String> sizesForEachFlavor2 = new LinkedHashMap<Integer, String>();
        //sizesForEachFlavor2.clear();
        String LatestFlavorName = "";
        try {
            click("flavorsDropdown");
            flavorName = getEachElement("flavorsAvailable", flavor).getAttribute("innerText");
            //ScrollTillElement(driver.findElements(By.xpath(prop.getLocator("flavorsAvailable"))), flavor);
            ((JavascriptExecutor) driver).executeScript("window.scrollBy(200,300)");

            getEachElement("flavorsAvailable", flavor).click();
            checkPageLoad();
            // ((JavascriptExecutor) driver).executeScript("window.scrollBy(100,200)");
            //checkBrokenImage(driver.findElement(By.xpath(prop.getLocator("ImagePDP"))).getAttribute("src"));
            try {
                checkBrokenImage(driver.findElement(By.xpath(prop.getLocator("ImagePDP"))).getAttribute("src"));
            } catch (Exception e) {
                String url = driver.getCurrentUrl();
                log("fail", "Image is not displayed for " + flavorName + " URL is " + url);
                captureScreenShot();
            }
            checkPreviewURL();
            sizesForEachFlavor = driver.findElements(By.xpath(prop.getLocator("sizesAvailable")));
            log("pass", "Verified Sizes, Images, Preview URL for Flavor " + flavorName);

        } catch (Exception e) {
            e.printStackTrace();
            String[] urlArray1 = driver.getCurrentUrl().split("/");
            LatestFlavorName = urlArray1[urlArray1.length - 1];
            log("fail", "Issue in the above PDP Page while changing " + LatestFlavorName + " flavor to next flavor drop down values inside flavors is getting changed");
        }
        return sizesForEachFlavor;
    }

    public List<WebElement> verifyCategoryForEachProductGrp2(int category, boolean categoryPresent) {
        List<WebElement> flavorForEachCategory = null;
        String categoryName = "";
        //((JavascriptExecutor) driver).executeScript("window.scrollBy(600,900)");
        try {
            if (categoryPresent) { //TODO: Category name locator need to be updated for Coke energy
                //categoryName = getEachElement("cokeExplore_Learn", category).getAttribute("innerText");
                categoryName = checkCategory(category);
            }
            checkPreviewURL();
            click("flavorsDropdown");
            flavorForEachCategory = driver.findElements(By.xpath(prop.getLocator("flavorsAvailable")));
            click("flavorsDropdown");
            if (!categoryName.equals("")) {
                logTitle(categoryName);
                log("pass", "Verified Image, Preview URL for Category ");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log("fail", "Error in category Page " + categoryName);
        }
        return flavorForEachCategory;
    }

    public LinkedHashMap<Integer, String> verifyCategoryForEachProduct(int category, boolean categoryPresent) {
        List<WebElement> temp = null;
        LinkedHashMap<Integer, String> flavorForEachCategory = new LinkedHashMap<Integer, String>();
        flavorForEachCategory.clear();
        String categoryName = "";
        try {
            if (categoryPresent) { //TODO: Category name locator need to be updated for Coke energy
                //categoryName = getEachElement("cokeExplore_Learn", category).getAttribute("innerText");
                categoryName = checkCategory(category);
            }
            checkPreviewURL();
            click("flavorsDropdown");
            temp = driver.findElements(By.xpath(prop.getLocator("flavorsAvailable")));
            for (int k = 0; k < temp.size(); k++) {
                String DropFlavorName = "";
                DropFlavorName = temp.get(k).getAttribute("innerText").trim();
                flavorForEachCategory.put(k, DropFlavorName);
            }
            click("flavorsDropdown");
            if (!categoryName.equals("")) {
                logTitle(categoryName);
                log("pass", "Verified Image, Preview URL for Category ");
            }
        } catch (Exception e) {
            e.printStackTrace();
            log("fail", "Error in category Page " + categoryName);
        }

        return flavorForEachCategory;
    }

    public String checkCategory(int category) {
        //TODO:Optimize locator for PLPContainerImage
        String categoryImageurl = "";
        try {
            if (driver.getCurrentUrl().contains("coca-cola-energy")) {
                categoryImageurl = getEachElement("PLPContainerImageEnergy", category).getAttribute("src");
            } else {
                categoryImageurl = getEachElement("PLPContainerImage", category).getAttribute("src");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // categoryImageurl = getEachElement("PLPContainerImageEnergy", category).getAttribute("src");

        //categoryImageurl = getEachElement("PLPContainerImage", category).getAttribute("src");
        checkBrokenImage(categoryImageurl);
        String categoryName = "";
        if ((categoryImageurl.contains("energy")) && (driver.getCurrentUrl().contains("coca-cola-energy"))) { //changed here
            categoryName = getEachElement("PLPEnergyimg", category).getAttribute("prodname");
            OpenInNewTab(getEachElement("PLPEnergyimg", category));
            checkPageLoad();
        } else if (driver.getCurrentUrl().contains("coca-cola-local-flavors")) {
            categoryName = getEachElement("PLPProductNameLocalTastes", category).getAttribute("innerText");
            OpenInNewTab(getEachElement("cokeExplore_Learn", category));
            checkPageLoad();
        } else if (driver.getCurrentUrl().contains("powerade")) {
            categoryName = getEachElement("Powerade.cokeExplore_Learn", category).getAttribute("innerText");
            OpenInNewTab(getEachElement("Powerade.Explore_Learn", category));
            checkPageLoad();
        } else if (driver.getCurrentUrl().contains("vitamin")) {
            categoryName = getEachElement("VitaWater.Explore_Learn", category).getAttribute("prodname");
            OpenInNewTab(getEachElement("VitaWater.Explore_Learn", category));
            checkPageLoad();
        } else {
            categoryName = getEachElement("PLPProductName", category).getAttribute("innerText");  //Changes made on 5/13 at 01:29 am
            OpenInNewTab(getEachElement("cokeExplore_Learn", category));
            checkPageLoad();
        }
        return retriveName(categoryName);
    }

    public List<WebElement> verifyProduct(int product) {
        List<WebElement> categoryForEachProduct = null;
        String productName = "";
        try {
            productName = getEachElement("PLPProductName", product).getAttribute("innerText");
            String productImageUrl = getEachElement("PLPContainerImage", product).getAttribute("src");
            checkBrokenImage(productImageUrl);
            OpenInNewTab(getEachElement("cokeExplore_Learn", product));
            productName = retriveName(productName);
            if (productName.contains("Coca-Cola Life")) {
                categoryForEachProduct = driver.findElements(By.xpath(prop.getLocator("apple")));
            } else if (productName.contains("POWERADE")) {
                categoryForEachProduct = driver.findElements(By.xpath(prop.getLocator("Powerade.Explore_Learn")));
            } else if (productName.contains("vitamin")) {
                categoryForEachProduct = driver.findElements(By.xpath(prop.getLocator("VitaWater.Explore_Learn")));
            } else {
                categoryForEachProduct = driver.findElements(By.xpath(prop.getLocator("cokeExplore_Learn")));
            }
            logTitle(productName);
            log("pass", "Verified Image, Preview URL on product " + productName);

        } catch (Exception e) {
            e.printStackTrace();
            log("fail", "Error in Product " + productName);
        }
        return categoryForEachProduct;
    }

    public List<WebElement> verifyProduct2(int product) {
        List<WebElement> categoryForEachProduct = null;
        String productName = "";
        try {
            if (driver.getCurrentUrl().contains("dunkin")) {
                productName = getEachElement("Dunkin.PLPProductName", product).getAttribute("innerText");
                String productImageUrl = getEachElement("PLPContainerZico", product).getAttribute("src");
                checkBrokenImage(productImageUrl);
                OpenInNewTab(getEachElement("Dunkin.PLPProduct", product));
                productName = retriveName(productName);
                logTitle(productName);
                categoryForEachProduct = driver.findElements(By.xpath(prop.getLocator("Zico.PLPProductName")));
            } else if (driver.getCurrentUrl().contains("zico")) {
                productName = getEachElement("Zico.PLPProductName", product).getAttribute("innerText");
                String productImageUrl = getEachElement("PLPContainerZico", product).getAttribute("src");
                checkBrokenImage(productImageUrl);
                OpenInNewTab(getEachElement("Zico.PLPProductName", product));
                productName = retriveName(productName);
                logTitle(productName);
                categoryForEachProduct = driver.findElements(By.xpath(prop.getLocator("Zico.PLPProductName")));
            } else if (driver.getCurrentUrl().contains("barqs")) {
                productName = getEachElement("Barqs.PLPProductName", product).getAttribute("innerText");
                String productImageUrl = getEachElement("PLPContainerImage", product).getAttribute("src");
                checkBrokenImage(productImageUrl);
                OpenInNewTab(getEachElement("Barqs.Explore_learn", product));
                productName = retriveName(productName);
                logTitle(productName);
                categoryForEachProduct = driver.findElements(By.xpath(prop.getLocator("Zico.PLPProductName")));
            } else if (driver.getCurrentUrl().contains("melloyello.com")) {
                productName = getEachElement("MelloYello.PLPProductName", product).getAttribute("prodname");
                String productImageUrl = getEachElement("PLPContainerZico", product).getAttribute("src");
                checkBrokenImage(productImageUrl);
                OpenInNewTab(getEachElement("MelloYello.PLPProductName", product));
                productName = retriveName(productName);
                logTitle(productName);
                categoryForEachProduct = driver.findElements(By.xpath(prop.getLocator("Zico.PLPProductName")));
            }
            log("pass", "Verified Image, Preview URL on product " + productName);

        } catch (Exception e) {
            e.printStackTrace();
            log("fail", "Error in Product " + productName);
        }
        return categoryForEachProduct;
    }

    public String retriveName(String name) {
        if ((name.equalsIgnoreCase("") || name.equalsIgnoreCase("learn more"))) {
            String[] urlArray = driver.getCurrentUrl().split("/");
            return urlArray[urlArray.length - 1];
        }
        return name;
    }

}
